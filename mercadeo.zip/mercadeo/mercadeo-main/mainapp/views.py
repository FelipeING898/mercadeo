from django.shortcuts import render

# Create your views here.

def index(request):
    return render(request, 'mainapp/index.html', {
        'title': 'Home'
    })
def login(request):
    return render(request, 'mainlogin/login.html',{
        'tittle': 'Login'
    })